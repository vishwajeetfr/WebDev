// eslint-disable-next-line no-undef
jQuery(document).ready(function ($) {
  const toggleBtn = $("#toggle-site-nav");
  $(toggleBtn).click(function () {
    $(this)
      .parent(".nav-primary__list-item")
      .toggleClass("nav_child__menu-open");
    $(this).parent().toggleClass("menu-open");
  });

  const dropBtn = $(".nav-primary__action--has-children");
  $(dropBtn).click(function () {
    $(this)
      .parent(".nav-primary__list-item")
      .toggleClass("nav_child__menu-open");
    $(this).parent().toggleClass("menu-open");
  });

  const toggle = $("#toggle-site-nav");
  $(toggle).click(function () {
    $("body").css("position", "");
    $(this).toggleClass("open");
  });

  const childSidebar = $(".nav-section__list-item--has-children");
  $(childSidebar).click(function () {
    $(this).toggleClass("nav-section__list-item--is-active");
  });

  const stickyHeader = $(".sticky-header");
  $(window).scroll(function () {
    const scroll = $(window).scrollTop();

    if (scroll >= 300) {
      stickyHeader.css("opacity", "1");
      stickyHeader.css("visibility", "visible");
    } else {
      stickyHeader.css("opacity", "0");
      stickyHeader.css("visibility", "hidden");
    }
  });

  $(window).scroll(function () {
    const winScroll =
      document.body.scrollTop || document.documentElement.scrollTop;
    const height =
      document.documentElement.scrollHeight -
      document.documentElement.clientHeight;
    const scrolled = (winScroll / height) * 100;
    const progress = document.getElementById("progress");
    progress ? (progress.style.width = scrolled + "%") : null;
  });

  $(".igger--site-nav").click(function () {
    if ($("#masthead").hasClass("masthead__nav--is-active")) {
      $("body").removeClass("no-scroll");
    } else {
      if ($(window).width() < 898) {
        const $title = $("#masthead").height();
        const $top = $("#site-navigation");
        $top.css({ top: $title });
      }
      $("body").addClass("no-scroll");
    }
  });

  $(window).resize(function () {
    if ($(window).width() > 898) {
      $("body").removeClass("no-scroll");
      $("header").removeClass("masthead__nav--is-active");
    }
  });

  $(".btn-accordion").data("closedAll", true);

  $(".btn-accordion").click(function () {
    if ($(this).data("closedAll")) {
      $(this).text("Collapse All");
      $(this).addClass("expanded");
      $(".collapse").collapse("show");
    } else {
      $(this).text("Expand All");
      $(this).removeClass("expanded");
      $(".collapse").collapse("hide");
    }

    // save last state
    $(this).data("closedAll", !$(this).data("closedAll"));
  });

  $('.accordion-collapse').on('show.bs.collapse', function () {
    $(this).parent().addClass('active');
  });

  $('.accordion-collapse').on('hide.bs.collapse', function () {
    $(this).parent().removeClass('active');
  });

});
